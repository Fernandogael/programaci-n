           #ejercisio 1
print("compra de estéreos")

si precio= float(input("Ingrese el precio del estéreo: "))
marca = input("Ingrese la marca del estéreo: ")

if precio_sin_iva >= 2000:
  descuento_precio = precio_sin_iva * 0.10
else:
  descuento_precio = 0

if marca == "CHONY":
  descuento_marca = precio_sin_iva * 0.05
else:
  descuento_marca = 0

precio_con_descuentos = precio_sin_iva - descuento_precio - descuento_marca

iva = precio_con_descuentos * 0.20

precio_final = precio_con_descuentos + iva

print("El precio final del estéreo es:", precio_final)






#ejercicio 2

       def calcular (edad):
    if edad < 5:
 
    return "Entrada gratuita"
    elif 5 <= edad <= 12:

     return "$5"
    elif 13 <= edad <= 17:
      
 return "$10"
    else:
        return "$15"





