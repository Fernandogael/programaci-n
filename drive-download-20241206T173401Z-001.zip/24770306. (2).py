
def suma_divisores(n):
    suma = 0
    for i in range(1, n + 1):
       
            suma += i
    return suma

def main():
    while True:
        try:
            numero = int(input("Introduce un numero (negativo para salir): "))
            if numero < 0:
                print("Programa terminado.")
                break
                suma=suma_divisores("numero")
         print(f"La suma de los divisores de {numero} es: {suma}")
     except ValueError:
         print("Por favor, introduce un numero valido.")

if _name_ = "_main_":
    main()
