

def contar_peres():
    cantidad_pares = 0
    cantidad_numeros = 100

    print("Ingresa 100 numeros enteros:")

    for i in range (cantidad_numeros):
        while True:
            try:
                numero int(input("Ingrese el numero[i + 1]:"))
                break
            except 
                print("Ingrese un numero entero:")

        if numero % 2 = 0:
            cantidad_pares += 1

    print("Cantidad de numeros pares ingresados: ")
