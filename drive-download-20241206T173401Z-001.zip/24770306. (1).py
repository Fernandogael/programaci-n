Se coloca un capital (c), a un interes (i) (que oscila entre 0 y
100), durante (m) años y se desea saber en cuanto se habra convertido ese
capital en (m) años, sabiendo que es acumulativo.

print("Calcular el Interes.")

c=-1
i=0
m=0
while(c<0)or(i<=0)or(i>=100)or(m<=0):
    print("Introduce el capital, interes y Años:")
    c=int(input("Capital: "))
    i=int(input("Interes: "))
    m=int(input("Años:    "))
     for i in range(m):
         c=c*(1+i/100)
      print("Tienes ",c," de capital acumulado")