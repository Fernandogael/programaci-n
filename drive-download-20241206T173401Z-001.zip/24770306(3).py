Escribe un programa que dados 3 numeros muestre el mensaje IGUALES si la suma
de los dos primeros es igual al otro numero y el mensaje DISTINTOS en caso contrario.

print("Ingrese 3 Numeros")
a = int (input("ingrese a: "))
b = int (input("ingrese b: "))
c = int (input("ingrese c: "))

if a+b==c :
    print("IGUALES")
else:
    print("DISTINTOS")





Escribe un programa que dado dos numeros "a" y "b" muestre sus valores en orden de mayor a menor

print("Ingrese 2 Números")
a = int (input("ingrese a: "))
b = int (input("ingrese b: "))

if a > b:
   print("a: , b: ")
else:
   print("b: , a: ")

Escriba un programa que dada una fecha del año 2000 (representada por el dia, mes y año en formato numérico dd/mm/aaa)
calcule el dia siguiente. Se asume que el mes tiene 30 dias.

print("Ingresa una fecha: ")
a = int (input("Año: "))
m= int (input("Mes: "))
d = int (input("Dia: "))


if d>0 and d<30 :
    print("Mañana es: ",d+1,m,a)
else:
   if m>0 and m<12:
       print("Mañana es: ",1, m+1, a)
   else:
        print("Mañana es: ", 1, 1, a+1)